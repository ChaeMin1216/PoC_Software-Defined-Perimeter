#!/usr/bin/env python3
import socket
import struct
import json
import threading
import sys
import time
import os
import subprocess
import datetime
import signal
from tls_util import make_client_ctx, make_server_ctx
import cert_manager

# ==========================================
# [통합 설정] Gateway Configuration
# ==========================================
# 1. Controller 정보
CONTROLLER_IP = '192.168.163.129'
CONTROLLER_IH_PORT = 4433  # IH로서 접속할 포트
CONTROLLER_AH_PORT = 4444  # AH로서 접속할 포트

# 2. [AH 역할] 이 Gateway가 보호할 로컬 서비스 (외부에서 들어올 때)
PROTECTED_TARGET_IP = '127.0.0.1'
PROTECTED_TARGET_PORT = 80  # 예: 로컬 웹서버, PLC 등

# 3. [IH 역할] 로컬 사용자가 접속할 진입점 (외부로 나갈 때)
LOCAL_PROXY_IP = '127.0.0.1'
LOCAL_PROXY_PORT = 5020

# 4. 파일 경로
FWKNOP_ACCESS_CONF = "/etc/fwknop/access.conf"

# [공유 자원] 파일 쓰기 충돌 방지용 Lock
file_lock = threading.Lock()

# ==========================================
# [공통 유틸리티]
# ==========================================
def recv_until_newline(sock):
    """줄바꿈 문자(\n)가 나올 때까지 읽는 함수"""
    data = b''
    while True:
        try:
            chunk = sock.recv(1)
            if not chunk: return None
            data += chunk
            if chunk == b'\n': break
        except: return None
    return data

def recvall(sock, n):
    """
    [중요] TCP 패킷 분할(Fragmentation) 방지 함수
    정확히 n바이트를 모두 수신할 때까지 반복해서 읽습니다.
    """
    data = b''
    while len(data) < n:
        try:
            packet = sock.recv(n - len(data))
            if not packet: return None # 연결 끊김
            data += packet
        except: return None
    return data

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect((CONTROLLER_IP, 80))
        ip = s.getsockname()[0]
    except: ip = "127.0.0.1"
    finally: s.close()
    return ip

# ==========================================
# [CLASS 1] AH 역할 (Inbound Traffic Handler)
# ==========================================
class SDP_Gateway_AH:
    def __init__(self):
        print(">>> [AH Role] 초기화 중...")
        cert_manager.ensure_device_cert("ah")
        self.client_ctx = make_client_ctx("ah")
        self.server_ctx = make_server_ctx("ah")
        self.my_ports = {"auth": 0, "data": 0}
        self.running = True
        self.controller_sock = None

    def update_access_conf(self, source_name, enc, hmac, port):
        """방화벽 설정 파일 안전 업데이트 (Lock 사용)"""
        ts = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        conf_block = f"\n# TEMP {source_name} {ts}\nSOURCE ANY\nKEY_BASE64 {enc}\nHMAC_KEY_BASE64 {hmac}\nOPEN_PORTS tcp/{port}\n"
        
        with file_lock: # Thread-Safe File Writing
            try:
                p = subprocess.Popen(['sudo', 'tee', '-a', FWKNOP_ACCESS_CONF], stdin=subprocess.PIPE, text=True)
                p.communicate(input=conf_block)
                subprocess.run(["sudo", "fwknopd", "-R"], check=False)
                
                # 자동 삭제 스케줄링
                del_cmd = f"sudo sed -i '/# TEMP {source_name} {ts}/,+5d' {FWKNOP_ACCESS_CONF}; sudo fwknopd -R"
                subprocess.run(f"echo \"{del_cmd}\" | at now + 24 hours", shell=True)
                print(f"[AH] 방화벽 Open: tcp/{port} (for {source_name})")
            except Exception as e:
                print(f"[AH] 방화벽 설정 실패: {e}")

    def handle_auth_client(self, conn, addr):
        try:
            cmd = recvall(conn, 1) # recv(1) -> recvall(conn, 1) 안전하게 변경
            if cmd and cmd[0] == 0x05: 
                payload = recv_until_newline(conn)
                info = json.loads(payload)
                c = info['IH Authenticators'].get('credentials', {})
                self.update_access_conf("IH", c['spa_encryption_key'], c['spa_hmac_key'], self.my_ports['data'])
        except: pass
        finally: conn.close()

    def relay_target_to_tunnel(self, target_sock, ih_conn, ids):
        try:
            while self.running:
                data = target_sock.recv(4096)
                if not data: break
                # [명세 준수] 0x09 + Length + ID(32) + Session(32) + Data
                packet = struct.pack("!BH", 0x09, len(data)) + ids + data
                ih_conn.sendall(packet)
        except: pass
        finally:
            try: ih_conn.shutdown(socket.SHUT_WR)
            except: pass

    def handle_data_client(self, ih_conn, addr):
        target_sock = None
        try:
            print(f"[AH-Data] IH 접속됨: {addr}")
            
            # [수정] recv -> recvall (65바이트 보장)
            req = recvall(ih_conn, 65)
            if not req or req[0] != 0x07: return
            
            # OK 응답 (0x08 + 200 + IDs)
            ih_conn.sendall(struct.pack("!BH", 0x08, 200) + req[1:])
            ids = req[1:] 

            # 실제 보호 대상 서비스 연결
            try:
                target_sock = socket.create_connection((PROTECTED_TARGET_IP, PROTECTED_TARGET_PORT), timeout=5)
            except Exception as e:
                print(f"[AH] Target 연결 실패: {e}")
                return

            # Relay 시작
            t = threading.Thread(target=self.relay_target_to_tunnel, args=(target_sock, ih_conn, ids), daemon=True)
            t.start()

            while self.running:
                # [수정] recv -> recvall로 헤더 읽기 안정화
                head = recvall(ih_conn, 3)
                if not head: break
                cmd, ln = struct.unpack("!BH", head)
                
                if cmd == 0x09: # Data
                    # [명세 준수] ID(32) + Session(32) = 64 bytes 헤더
                    full_len = 64 + ln
                    
                    # [수정] while loop 대신 recvall 사용 (코드 간소화 및 안전성 확보)
                    payload = recvall(ih_conn, full_len)
                    if not payload: break

                    real_data = payload[64:] # 헤더 제거
                    target_sock.sendall(real_data)
                    
                elif cmd == 0x0A: # Close
                    break
        except Exception as e:
            print(f"[AH-Data] Error: {e}")
        finally:
            if target_sock: target_sock.close()
            ih_conn.close()

    def start_listener(self, role, handler):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('0.0.0.0', 0)) 
        port = s.getsockname()[1]
        self.my_ports[role] = port
        s.listen(5)
        print(f"[AH Role] {role} Port Listening on: {port}")
        
        while self.running:
            try:
                conn, addr = s.accept()
                tls = self.server_ctx.wrap_socket(conn, server_side=True)
                threading.Thread(target=handler, args=(tls, addr), daemon=True).start()
            except: pass

    def run(self):
        # 1. 리스너 스레드 시작
        threading.Thread(target=self.start_listener, args=("auth", self.handle_auth_client), daemon=True).start()
        threading.Thread(target=self.start_listener, args=("data", self.handle_data_client), daemon=True).start()
        
        time.sleep(1)
        
        print(f"[AH Role] Controller({CONTROLLER_AH_PORT}) 접속 시도...")
        os.system(f"fwknop -n {CONTROLLER_IP} --fw-timeout 60 > /dev/null 2>&1")
        
        try:
            raw = socket.create_connection((CONTROLLER_IP, CONTROLLER_AH_PORT))
            self.controller_sock = self.client_ctx.wrap_socket(raw, server_hostname="sdp-controller")
            
            # Login
            login = {"device_id": "ah01", "data_port": self.my_ports['data'], "auth_port": self.my_ports['auth']}
            self.controller_sock.sendall(bytes([0x00]) + json.dumps(login).encode('utf-8') + b'\n')
            
            self.controller_sock.recv(3)
            resp = json.loads(recv_until_newline(self.controller_sock))
            print("[AH Role] Controller 로그인 성공")
            
            if 'controller_auth_keys' in resp:
                ck = resp['controller_auth_keys']
                self.update_access_conf("Controller", ck['enc'], ck['hmac'], self.my_ports['auth'])

            self.controller_sock.recv(1); recv_until_newline(self.controller_sock)

            # Keep-Alive
            while self.running:
                if not self.controller_sock.recv(1): break
                self.controller_sock.sendall(bytes([0x03]))

        except Exception as e:
            print(f"[AH Role] Error: {e}")
        finally:
            self.shutdown()

    def shutdown(self):
        self.running = False
        if self.controller_sock:
            try:
                print("[AH Role] 로그아웃(0x02) 전송")
                self.controller_sock.sendall(bytes([0x02])) # [명세 준수]
            except: pass
            self.controller_sock.close()


# ==========================================
# [CLASS 2] IH 역할 (Outbound Traffic Handler)
# ==========================================
class SDP_Gateway_IH:
    def __init__(self):
        print(">>> [IH Role] 초기화 중...")
        cert_manager.ensure_device_cert("ih")
        self.client_ctx = make_client_ctx("ih")
        self.running = True
        self.controller_sock = None
        self.proxy_listener = None

    def relay_local_to_tunnel(self, local_sock, tunnel_sock, ids):
        try:
            while True:
                data = local_sock.recv(4096)
                if not data: break
                packet = struct.pack("!BH", 0x09, len(data)) + ids + data
                tunnel_sock.sendall(packet)
        except: pass
        finally:
            try: tunnel_sock.shutdown(socket.SHUT_WR)
            except: pass

    def relay_tunnel_to_local(self, tunnel_sock, local_sock):
        try:
            while True:
                # [수정] recvall로 헤더 읽기
                head = recvall(tunnel_sock, 3)
                if not head: break
                cmd, ln = struct.unpack("!BH", head)
                
                if cmd == 0x09:
                    full_len = 64 + ln
                    # [수정] recvall로 페이로드 읽기
                    payload = recvall(tunnel_sock, full_len)
                    if not payload: break
                    
                    local_sock.sendall(payload[64:]) # 헤더 제거 후 전달
                elif cmd == 0x0A:
                    break
        except: pass
        finally:
            try: local_sock.close()
            except: pass

    def start_proxy_service(self, svc, sess, spa_enc, spa_hmac):
        target_ip = svc['address']
        target_port = svc['port']

        try:
            self.proxy_listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.proxy_listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.proxy_listener.bind((LOCAL_PROXY_IP, LOCAL_PROXY_PORT))
            self.proxy_listener.listen(5)
            
            print(f"\n[IH Role] Proxy Started on {LOCAL_PROXY_IP}:{LOCAL_PROXY_PORT}")
            print(f"[IH Role] Target: {svc['name']} via Gateway {target_ip}")
            print("[IH Role] Ready for connection... (Listening)")

            while self.running:
                try:
                    # 사용자 접속 대기 (블로킹)
                    user_sock, user_addr = self.proxy_listener.accept()
                    
                    # SPA (fwknop)
                    my_ip = get_local_ip()
                    fwknop_cmd = (
                        f"/usr/bin/fwknop -A tcp/{target_port} --fw-timeout 1800 --use-hmac "
                        f"--key-base64-rijndael '{spa_enc}' --key-base64-hmac '{spa_hmac}' "
                        f"-D {target_ip} -a {my_ip} -R"
                    )
                    os.system(fwknop_cmd + " > /dev/null 2>&1")
                    time.sleep(1.5)

                    # Tunnel Connect
                    raw = socket.create_connection((target_ip, target_port), timeout=5)
                    tunnel_sock = self.client_ctx.wrap_socket(raw, server_hostname="sdp-ah")

                    # Handshake [명세 준수 + 방어 코드]
                    try:
                        svc_id_bytes = bytes.fromhex(svc['id'])
                    except: 
                        svc_id_bytes = svc['id'].encode() # Fallback for non-hex
                    
                    # ★ [중요] ID Padding/Truncating: 무조건 32바이트 맞춤
                    svc_id_bytes = svc_id_bytes.ljust(32, b'\0')[:32]

                    ids = (svc_id_bytes + sess.encode().ljust(32, b'\0')[:32])
                    tunnel_sock.sendall(bytes([0x07]) + ids)

                    # [수정] recvall로 67바이트 보장
                    if not recvall(tunnel_sock, 67):
                        user_sock.close(); tunnel_sock.close(); continue

                    # Start Relay
                    t1 = threading.Thread(target=self.relay_local_to_tunnel, args=(user_sock, tunnel_sock, ids), daemon=True)
                    t2 = threading.Thread(target=self.relay_tunnel_to_local, args=(tunnel_sock, user_sock), daemon=True)
                    t1.start(); t2.start()
                    t1.join(); t2.join()
                    
                except socket.timeout: pass
                except Exception as e: print(f"[IH Proxy] Error: {e}")

        except Exception as e:
            print(f"[IH Proxy] Listener Error: {e}")
        finally:
            if self.proxy_listener: self.proxy_listener.close()

    def run(self):
        # [중요] 재시작을 위해 running 플래그 초기화
        self.running = True
        
        print(f"[IH Role] Controller({CONTROLLER_IH_PORT}) 접속 시도...")
        os.system(f"fwknop -n {CONTROLLER_IP} --fw-timeout 60 > /dev/null 2>&1")
        time.sleep(1)

        try:
            raw = socket.create_connection((CONTROLLER_IP, CONTROLLER_IH_PORT))
            self.controller_sock = self.client_ctx.wrap_socket(raw, server_hostname="sdp-controller")

            self.controller_sock.sendall(bytes([0x00])) # Login
            self.controller_sock.recv(3)
            login = json.loads(recv_until_newline(self.controller_sock))
            print("[IH Role] Controller 로그인 성공")

            self.controller_sock.sendall(bytes([0x03])) # Keep-Alive
            self.controller_sock.recv(1)

            # Service Info 수신
            cmd = self.controller_sock.recv(1)
            if cmd and cmd[0] == 0x06:
                info = json.loads(recv_until_newline(self.controller_sock))
                if info.get('services'):
                    tgt = info['services'][0]
                    
                    # Controller 연결 끊기 전 로그아웃 [명세 준수]
                    print("[IH Role] 로그아웃(0x07) 전송 후 프록시 모드 진입")
                    try: self.controller_sock.sendall(bytes([0x07]))
                    except: pass
                    self.controller_sock.close()
                    self.controller_sock = None
                    
                    self.start_proxy_service(
                        tgt, login['session_id'],
                        login['credentials']['spa_encryption_key'],
                        login['credentials']['spa_hmac_key']
                    )
                else:
                    print("[IH Role] 사용 가능한 서비스가 없습니다.")
            
        except Exception as e:
            print(f"[IH Role] Error: {e}")
        finally:
            if self.controller_sock:
                try: self.controller_sock.sendall(bytes([0x07]))
                except: pass
                self.controller_sock.close()
    
    def shutdown(self):
        self.running = False
        if self.proxy_listener:
            self.proxy_listener.close()
        print("[IH Role] Shutdown signal received.")

# ==========================================
# [Main] 통합 실행 (Menu Driven)
# ==========================================
def main():
    print("=== SDP Unified Gateway Started (Interactive Mode) ===")
    
    # 1. AH 모듈 (항상 실행)
    #    백그라운드 스레드에서 돌지만, print 문은 콘솔에 출력됨
    ah_module = SDP_Gateway_AH()
    t_ah = threading.Thread(target=ah_module.run, daemon=True)
    t_ah.start()
    print("[System] AH Module started in background. (Logs will appear below)")

    # 2. IH 모듈 인스턴스 생성 (실행은 메뉴에서)
    ih_module = SDP_Gateway_IH()
    t_ih = None

    while True:
        try:
            print("\n--------------------------------")
            print("   SDP Gateway Control Panel")
            print("--------------------------------")
            print("1. Start IH (Connect & Proxy)")
            print("2. Stop IH")
            print("0. Exit Gateway")
            
            cmd = input("Select > ").strip()

            if cmd == '1':
                if t_ih and t_ih.is_alive():
                    print("[System] IH is already running!")
                else:
                    print("[System] Starting IH Module...")
                    t_ih = threading.Thread(target=ih_module.run, daemon=True)
                    t_ih.start()
            
            elif cmd == '2':
                if t_ih and t_ih.is_alive():
                    print("[System] Stopping IH Module...")
                    ih_module.shutdown()
                    t_ih.join(timeout=2)
                    print("[System] IH Stopped.")
                else:
                    print("[System] IH is not running.")

            elif cmd == '0':
                print("[System] Shutting down everything...")
                ah_module.shutdown()
                if t_ih and t_ih.is_alive():
                    ih_module.shutdown()
                print("Bye!")
                break
            
            else:
                print("[System] Invalid command.")
        
        except KeyboardInterrupt:
            print("\n[System] Force Exit detected.")
            break
        except Exception as e:
            print(f"[System] Menu Error: {e}")

if __name__ == '__main__':
    main()
