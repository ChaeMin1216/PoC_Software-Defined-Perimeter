#!/usr/bin/env python3
import socket
import struct
import json
import time
import threading
import sys
import os
import subprocess
import sqlite3
import hashlib
from tls_util import make_server_ctx, make_client_ctx
import cert_manager

# ==========================================
# [설정]
# ==========================================
BIND_IP = '0.0.0.0'
IH_PORT = 4433
AH_PORT = 4444
DB_FILE = "sdp_controller.db"

# [메모리 캐시] 현재 접속 중인 AH의 실시간 위치 정보
# format: { "device_id": { "ip": "...", "auth_port": 1234, "data_port": 5678, "session": "..." } }
active_gateways = {}

print(">>> [Controller] 인증서 확인...")
cert_manager.ensure_device_cert("controller")
SERVER_CTX = make_server_ctx("controller")
CLIENT_CTX_TO_AH = make_client_ctx("controller")
print(">>> [Controller] 준비 완료\n")

# ==========================================
# [Database] SQLite 초기화 및 조회
# ==========================================
def init_db():
    conn = sqlite3.connect(DB_FILE)
    
    # 성능 향상을 위한 WAL 모드 (동시성 처리)
    conn.execute("PRAGMA journal_mode=WAL;")
    
    c = conn.cursor()
    
    # 1. Gateways 테이블
    c.execute('''CREATE TABLE IF NOT EXISTS gateways 
                 (device_id TEXT PRIMARY KEY, name TEXT)''')
    
    # 2. Services 테이블
    c.execute('''CREATE TABLE IF NOT EXISTS services 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  service_id TEXT UNIQUE, 
                  gateway_id TEXT, 
                  name TEXT, 
                  type TEXT, 
                  target_ip TEXT, 
                  target_port INTEGER,
                  FOREIGN KEY(gateway_id) REFERENCES gateways(device_id))''')

    # 3. Policies 테이블
    c.execute('''CREATE TABLE IF NOT EXISTS policies 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_cn TEXT, 
                  service_id TEXT,
                  FOREIGN KEY(service_id) REFERENCES services(service_id))''')

    # 하드코딩된 INSERT 구문은 제거됨 (관리자 도구 db_manager.py 사용)

    conn.commit()
    conn.close()
    print("[DB] 데이터베이스 초기화 및 테이블 로드 완료.")

def get_allowed_services(user_cn):
    """
    특정 사용자(user_cn)에게 허용된 서비스 목록을 조회하고,
    해당 서비스가 속한 Gateway가 현재 'Active' 상태인지 확인하여 반환
    """
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    # RBAC 쿼리: 정책 테이블 + 서비스 테이블 + 게이트웨이 테이블 조인
    query = '''
        SELECT s.service_id, s.name, s.type, s.target_ip, s.target_port, s.gateway_id
        FROM policies p
        JOIN services s ON p.service_id = s.service_id
        WHERE p.user_cn = ?
    '''
    c.execute(query, (user_cn,))
    rows = c.fetchall()
    conn.close()
    
    result_list = []
    for r in rows:
        gw_id = r['gateway_id']
        # 해당 서비스의 Gateway가 현재 접속 중(Active)인지 확인
        if gw_id in active_gateways:
            gw_info = active_gateways[gw_id]
            
            # IH에게 줄 서비스 명세서 생성 (규격 준수)
            svc_obj = {
                "id": r['service_id'],     # 64-char hex (DB값)
                "name": r['name'],
                "type": r['type'],
                "address": gw_info['ip'],  # AH의 현재 공인 IP
                "port": gw_info['data_port'] # AH의 터널링 포트
            }
            result_list.append(svc_obj)
            
    return result_list

# ==========================================
# [기능] 유틸리티
# ==========================================
def recv_until_newline(sock):
    data = b''
    while True:
        try:
            chunk = sock.recv(1)
            if not chunk: return None
            data += chunk
            if chunk == b'\n': break
        except: return None
    return data

def get_fwknop_keys():
    try:
        output = subprocess.check_output(["fwknop", "--key-gen"], stderr=subprocess.STDOUT)
        out_str = output.decode("utf-8")
        enc, hmac = None, None
        for line in out_str.splitlines():
            if line.startswith("KEY_BASE64:"): enc = line.split(":", 1)[1].strip()
            elif line.startswith("HMAC_KEY_BASE64:"): hmac = line.split(":", 1)[1].strip()
        if enc and hmac: return enc, hmac
        raise Exception("Key Parse Error")
    except: return "def_enc", "def_hmac"

# ★ [복구됨] Controller가 AH에게 접속하기 위해 로컬 설정을 갱신하는 함수
def update_local_fwknoprc(target_ip, target_port, enc, hmac):
    rc_file = os.path.expanduser("~/.fwknoprc")
    stanza = (
        f"\n[{target_ip}]\n"
        f"ALLOW_IP 0.0.0.0\n"
        f"ACCESS tcp/{target_port}\n"
        f"SPA_SERVER {target_ip}\n"
        f"KEY_BASE64 {enc}\n"
        f"HMAC_KEY_BASE64 {hmac}\n"
        f"USE_HMAC Y\n"
    )
    try:
        with open(rc_file, "a") as f:
            f.write(stanza)
        os.chmod(rc_file, 0o600)
    except Exception as e:
        print(f"[Warning] .fwknoprc 업데이트 실패: {e}")

def send_auth_to_ah(gw_info, auth_info):
    """AH에게 사용자(IH) 접속 승인 정보 전송"""
    ip = gw_info['ip']
    port = gw_info['auth_port']
    try:
        print(f"[Controller] AH({ip}:{port})에게 키 배포 시도...")
        # .fwknoprc에 저장된 키를 이용해 SPA 패킷 전송
        os.system(f"fwknop -A tcp/{port} --fw-timeout 60 -n {ip}")
        time.sleep(1.5) # AH 방화벽 Open 대기
        
        raw = socket.create_connection((ip, port), timeout=5)
        sock = CLIENT_CTX_TO_AH.wrap_socket(raw, server_hostname="sdp-ah")
        sock.sendall(bytes([0x05]) + json.dumps(auth_info).encode('utf-8') + b'\n')
        sock.close()
        print(f"[Controller] AH에게 키 배포 성공.")
        return True
    except Exception as e: 
        print(f"[Controller] AH 전송 실패: {e}")
        return False

# ==========================================
# [Handler] IH (사용자)
# ==========================================
def handle_ih(conn, addr):
    print(f"[Controller-IH] IH 접속: {addr}")
    try:
        if not conn.recv(1): return # Login Request (0x00)
        
        # [인증] 현재는 테스트를 위해 'client'로 고정
        user_cn = "client" 
        
        sess_id = os.urandom(32).hex()
        enc, hmac = get_fwknop_keys()
        
        # 1. Login Response
        resp = {"session_id": sess_id, "credentials": {"spa_encryption_key": enc, "spa_hmac_key": hmac}}
        conn.sendall(struct.pack("!BH", 0x01, 200) + json.dumps(resp).encode('utf-8') + b'\n')
        
        if conn.recv(1): conn.sendall(bytes([0x03])) # Keep-Alive Handshake

        # 2. RBAC: 이 사용자에게 허용된 서비스 조회 (DB)
        allowed_services = get_allowed_services(user_cn)
        
        if not allowed_services:
            print(f"[Controller-IH] 사용자({user_cn})에게 할당된 활성 서비스가 없습니다.")
        
        # 3. 관련 AH들에게 키 배포 (SPA Open 준비)
        target_gateways = set()
        for svc in allowed_services:
             for gw_id, info in active_gateways.items():
                 # 서비스의 실제 위치(IP/Port)와 일치하는 활성 게이트웨이 찾기
                 if info['ip'] == svc['address'] and info['data_port'] == svc['port']:
                     target_gateways.add(gw_id)

        auth_info = {
            "IH Authenticators": {
                "IH": f"IH_{addr[0]}", 
                "credentials": {"spa_encryption_key": enc, "spa_hmac_key": hmac}
            }
        }
        
        for gw_id in target_gateways:
            gw_info = active_gateways[gw_id]
            send_auth_to_ah(gw_info, auth_info)

        # 4. 서비스 목록 전송 (0x06)
        payload = json.dumps({"services": allowed_services}).encode('utf-8')
        conn.sendall(bytes([0x06]) + payload + b'\n')
        print(f"[Controller-IH] 서비스 목록({len(allowed_services)}개) 전송 완료")

        while True:
            cmd = conn.recv(1)
            if not cmd or cmd[0] == 0x07: break
            if cmd[0] == 0x03: conn.sendall(bytes([0x03]))
            
    except Exception as e: print(f"[IH-Error] {e}")
    finally: conn.close()

# ==========================================
# [Handler] AH (게이트웨이)
# ==========================================
def handle_ah(conn, addr):
    print(f"[Controller-AH] AH 접속 시도: {addr}")
    sess = None
    device_id = None
    try:
        if not conn.recv(1): return # Login
        req = json.loads(recv_until_newline(conn))
        
        device_id = req.get('device_id')
        
        # DB 검증: 등록된 Gateway인지 확인
        con_db = sqlite3.connect(DB_FILE)
        cursor = con_db.cursor()
        cursor.execute("SELECT name FROM gateways WHERE device_id=?", (device_id,))
        row = cursor.fetchone()
        con_db.close()
        
        if not row:
            print(f"[Controller-AH] 미등록 장비 접속 거부: {device_id}")
            return
            
        print(f"[Controller-AH] '{row[0]}'({device_id}) 로그인 성공")

        sess = os.urandom(16).hex()
        
        # 메모리에 활성 상태 등록
        active_gateways[device_id] = {
            "ip": addr[0], 
            "auth_port": req['auth_port'], 
            "data_port": req['data_port'],
            "session": sess
        }
        print(f"[Controller-AH] 활성 목록 등록됨: {device_id} -> {active_gateways[device_id]}")

        # Controller -> AH 인증용 키 교환
        c_enc, c_hmac = get_fwknop_keys()
        
        # [중요] Controller가 AH 접속 시 사용할 키를 로컬 설정에 저장
        update_local_fwknoprc(addr[0], req['auth_port'], c_enc, c_hmac)
        
        resp = {
            "session_id": sess,
            "controller_auth_keys": {"enc": c_enc, "hmac": c_hmac}
        }
        conn.sendall(struct.pack("!BH", 0x01, 200) + json.dumps(resp).encode('utf-8') + b'\n')
        conn.sendall(bytes([0x04]) + json.dumps({"services": []}).encode('utf-8') + b'\n')

        while True:
            cmd = conn.recv(1)
            if not cmd: break
            
            if cmd[0] == 0x02: # 로그아웃 요청 확인
                print(f"[Controller-AH] 로그아웃 요청(0x02) 수신. 종료.")
                break

            conn.sendall(bytes([0x03])) # Keep-Alive Ack
            
    except Exception as e: 
        print(f"[AH-Error] {e}")
    finally:
        if device_id and device_id in active_gateways:
            del active_gateways[device_id]
            print(f"[Controller-AH] {device_id} 접속 종료 및 목록 제거")
        conn.close()

def serve(port, handler):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((BIND_IP, port))
    s.listen(5)
    while True:
        try:
            c, a = s.accept()
            t = SERVER_CTX.wrap_socket(c, server_side=True)
            threading.Thread(target=handler, args=(t, a)).start()
        except: pass

if __name__ == '__main__':
    init_db() # DB 초기화
    threading.Thread(target=serve, args=(IH_PORT, handle_ih), daemon=True).start()
    threading.Thread(target=serve, args=(AH_PORT, handle_ah), daemon=True).start()
    print("[Controller] 서버 가동 중 (DB Mode)...")
    while True: time.sleep(1)
